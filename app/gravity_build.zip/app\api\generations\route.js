import { NextResponse } from 'next/server';
import { storage } from '@/lib/storage';

export async function GET() {
    const generations = storage.getGenerations();
    return NextResponse.json({ success: true, generations });
}
